#include "test_support.hpp"

#include <catch2/catch_test_macros.hpp>

#include "iprop/Binary.hpp"
#include "iprop/VM.hpp"

#include <cstring>
#include <string>

namespace test_support {

std::vector<u8> makeLayout(const std::vector<std::pair<SectionId, std::size_t>>& defs,
                           u32 flags, u16 minor) {
    iprop::Writer w;
    for (const u8 magic : iprop::kMagic) {
        w.writeU8(magic);
    }
    w.writeU16(iprop::kVersionMajor);
    w.writeU16(minor);
    w.writeU32(flags);
    w.writeU32(static_cast<u32>(defs.size()));
    w.writeU32(0); // reserved

    u32 offset = iprop::kHeaderSize + static_cast<u32>(defs.size()) * 12;
    for (const auto& [id, size] : defs) {
        w.writeU32(static_cast<u32>(id));
        w.writeU32(offset);
        w.writeU32(static_cast<u32>(size));
        offset += static_cast<u32>(size);
    }
    for (const auto& [id, size] : defs) {
        (void)id;
        for (std::size_t i = 0; i < size; ++i) {
            w.writeU8(0xAB);
        }
    }
    return w.data();
}

std::vector<u8> rawLayout(u16 major, u16 minor, u32 flags, u32 count, u32 reserved,
                          std::initializer_list<std::array<u32, 3>> entries) {
    iprop::Writer w;
    for (const u8 magic : iprop::kMagic) {
        w.writeU8(magic);
    }
    w.writeU16(major);
    w.writeU16(minor);
    w.writeU32(flags);
    w.writeU32(count);
    w.writeU32(reserved);
    for (const auto& [id, offset, size] : entries) {
        w.writeU32(id);
        w.writeU32(offset);
        w.writeU32(size);
    }
    return w.data();
}

void appendZeros(std::vector<u8>& bytes, std::size_t n) {
    bytes.insert(bytes.end(), n, 0);
}

std::vector<u8> constSection(const std::vector<std::string>& strings,
                             const std::vector<i32>& ints,
                             const std::vector<f32>& floats,
                             const std::vector<Color>& colors) {
    iprop::Writer w;
    w.writeU32(static_cast<u32>(strings.size()));
    for (const auto& s : strings) {
        w.writeU32(static_cast<u32>(s.size()));
        w.writeBytes({reinterpret_cast<const u8*>(s.data()), s.size()});
    }
    w.writeU32(static_cast<u32>(ints.size()));
    for (const i32 v : ints) {
        w.writeI32(v);
    }
    w.writeU32(static_cast<u32>(floats.size()));
    for (const f32 v : floats) {
        w.writeF32(v);
    }
    w.writeU32(static_cast<u32>(colors.size()));
    for (const Color c : colors) {
        w.writeColor(c);
    }
    return w.data();
}

std::vector<u8> ins(u8 opcode, u8 aux, u16 operand) {
    return {opcode, aux, static_cast<u8>(operand & 0xFF), static_cast<u8>(operand >> 8)};
}

std::vector<u8> retIns() { return ins(0x09, 0, 0); }

FuncSpec drawSpec(const std::vector<u8>& body, u32 nameIndex,
                  const std::vector<u8>& params) {
    return {nameIndex, params, {}, {}, body};
}

std::vector<u8> codeSection(const std::vector<FuncSpec>& funcs,
                            const std::vector<PartSpec>& parts) {
    iprop::Writer w;
    w.writeU32(static_cast<u32>(funcs.size()));
    u32 offset = 0;
    for (const auto& f : funcs) {
        w.writeU32(f.nameIndex);
        w.writeU32(offset);
        w.writeU32(static_cast<u32>(f.instructions.size()));
        offset += static_cast<u32>(f.instructions.size());
        w.writeU16(static_cast<u16>(f.paramTypes.size()));
        for (const u8 t : f.paramTypes) w.writeU8(t);
        w.writeU16(static_cast<u16>(f.resultTypes.size()));
        for (const u8 t : f.resultTypes) w.writeU8(t);
        w.writeU16(static_cast<u16>(f.localTypes.size()));
        for (const u8 t : f.localTypes) w.writeU8(t);
    }
    for (const auto& f : funcs) {
        w.writeBytes(f.instructions);
    }
    w.writeU32(static_cast<u32>(parts.size()));
    for (const auto& p : parts) {
        w.writeU32(p.funcIndex);
        w.writeU32(p.sizeX);
        w.writeU32(p.sizeY);
        w.writeF32(p.ox);
        w.writeF32(p.oy);
        w.writeU16(static_cast<u16>(p.inputs.size()));
        for (const auto& in : p.inputs) {
            w.writeU8(in.type);
            w.writeU32(in.nameIndex);
            if (in.type == 0) {
                w.writeColor(in.c);
            } else if (in.type == 1) {
                w.writeF32(in.f);
            } else {
                w.writeU32(in.u);
            }
        }
        w.writeU16(static_cast<u16>(p.outputs.size()));
        for (const auto& out : p.outputs) {
            w.writeU8(out.kind);
            w.writeU8(out.list);
            w.writeU8(0);
            w.writeU8(0);
            w.writeU32(out.nameIndex);
        }
    }
    return w.data();
}

std::vector<u8> minimalMeta() {
    return metaSection(8, 8, 0, 0, 1, 1, 1000, false, {}, 0, 0, 0, {}, {});
}

std::vector<u8> metaSection(u32 sizeX, u32 sizeY, f32 ox, f32 oy, u32 variants,
                            u32 archetypes, u64 fuel, bool emission, Color emColor,
                            f32 emX, f32 emY, f32 emR,
                            const std::vector<InputSpec>& inputs,
                            const std::vector<OutputSpec>& outputs,
                            u16 extraFlags) {
    iprop::Writer w;
    w.writeU32(sizeX);
    w.writeU32(sizeY);
    w.writeF32(ox);
    w.writeF32(oy);
    w.writeU32(variants);
    w.writeU32(archetypes);
    w.writeU64(fuel);
    w.writeU16(static_cast<u16>((emission ? 1u : 0u) | extraFlags));
    for (int i = 0; i < 6; ++i) {
        w.writeU8(0); // reserved
    }
    if (emission) {
        w.writeColor(emColor);
        w.writeF32(emX);
        w.writeF32(emY);
        w.writeF32(emR);
    }
    w.writeU16(static_cast<u16>(inputs.size()));
    for (const auto& in : inputs) {
        w.writeU8(in.type);
        w.writeU32(in.nameIndex);
        if (in.type == 0) {
            w.writeColor(in.c);
        } else if (in.type == 1) {
            w.writeF32(in.f);
        } else {
            w.writeU32(in.u);
        }
    }
    w.writeU16(static_cast<u16>(outputs.size()));
    for (const auto& out : outputs) {
        w.writeU8(out.kind);
        w.writeU8(out.list);
        w.writeU8(0);
        w.writeU8(0);
        w.writeU32(out.nameIndex);
    }
    return w.data();
}

std::vector<u8> fullFile(const std::vector<u8>& meta, const std::vector<u8>& pool,
                         const std::vector<u8>& code) {
    iprop::Writer w;
    for (const u8 m : iprop::kMagic) {
        w.writeU8(m);
    }
    w.writeU16(iprop::kVersionMajor);
    w.writeU16(iprop::kVersionMinor);
    w.writeU32(0);
    w.writeU32(3);
    w.writeU32(0);
    u32 off = iprop::kHeaderSize + 3 * 12;
    w.writeU32(1);
    w.writeU32(off);
    w.writeU32(static_cast<u32>(meta.size()));
    off += static_cast<u32>(meta.size());
    w.writeU32(2);
    w.writeU32(off);
    w.writeU32(static_cast<u32>(pool.size()));
    off += static_cast<u32>(pool.size());
    w.writeU32(3);
    w.writeU32(off);
    w.writeU32(static_cast<u32>(code.size()));
    off += static_cast<u32>(code.size());
    w.writeBytes(meta);
    w.writeBytes(pool);
    w.writeBytes(code);
    return w.data();
}

std::vector<u8> namesPool(const std::vector<std::string>& names) {
    return constSection(names, {}, {}, {});
}

std::vector<u8> richPool(const std::vector<std::string>& names) {
    return constSection(names, {0}, {0.f}, {{0, 0, 0, 255}});
}

Prog& Prog::emit(u8 opcode, u16 operand) {
    for (const auto b : ins(opcode, 0, operand)) body.push_back(b);
    return *this;
}

Prog& Prog::I(i32 value) {
    u16 index = 0;
    for (u16 i = 0; i < ints.size(); ++i) {
        if (ints[i] == value) {
            index = i;
            goto foundInt;
        }
    }
    ints.push_back(value);
    index = static_cast<u16>(ints.size() - 1);
foundInt:
    emit(0x10, index);
    return *this;
}

Prog& Prog::F(f32 value) {
    u16 index = 0;
    for (u16 i = 0; i < floats.size(); ++i) {
        if (std::memcmp(&floats[i], &value, sizeof(f32)) == 0) {
            index = i;
            goto foundFloat;
        }
    }
    floats.push_back(value);
    index = static_cast<u16>(floats.size() - 1);
foundFloat:
    emit(0x11, index);
    return *this;
}

Prog& Prog::C(Color value) {
    u16 index = 0;
    for (u16 i = 0; i < colors.size(); ++i) {
        if (colors[i] == value) {
            index = i;
            goto foundColor;
        }
    }
    colors.push_back(value);
    index = static_cast<u16>(colors.size() - 1);
foundColor:
    emit(0x12, index);
    return *this;
}

std::vector<u8> buildProgFile(const Prog& prog, u32 sizeX, u32 sizeY) {
    const auto meta =
        metaSection(sizeX, sizeY, 0, 0, 1, 1, 100000, false, {}, 0, 0, 0, {}, {});
    const auto pool = constSection({"draw"}, prog.ints, prog.floats, prog.colors);
    return fullFile(meta, pool, codeSection({{0, {0, 0}, {}, {}, prog.body}}, {}));
}

std::vector<iprop::Value> evalProg(const Prog& prog) {
    // The file bytes must outlive the LoadedFile: its spans point into them.
    const auto bytes = buildProgFile(prog);
    auto loaded = iprop::loadFile(bytes);
    iprop::VM vm(loaded, {});
    vm.run();
    return vm.debugStack();
}

i32 evalProgI32(const Prog& prog) {
    const auto stack = evalProg(prog);
    REQUIRE(stack.size() == 1);
    REQUIRE(std::holds_alternative<i32>(stack[0]));
    return std::get<i32>(stack[0]);
}

f32 evalProgF32(const Prog& prog) {
    const auto stack = evalProg(prog);
    REQUIRE(stack.size() == 1);
    REQUIRE(std::holds_alternative<f32>(stack[0]));
    return std::get<f32>(stack[0]);
}

Color evalProgColor(const Prog& prog) {
    const auto stack = evalProg(prog);
    REQUIRE(stack.size() == 1);
    REQUIRE(std::holds_alternative<Color>(stack[0]));
    return std::get<Color>(stack[0]);
}

void expectProgTrap(const Prog& prog, const char* messagePart) {
    const auto bytes = buildProgFile(prog); // must outlive the LoadedFile spans
    auto loaded = iprop::loadFile(bytes);
    bool threw = false;
    try {
        iprop::VM vm(loaded, {});
        vm.run();
    } catch (const iprop::Trap& error) {
        threw = true;
        REQUIRE(std::string(error.what()).find(messagePart) != std::string::npos);
    }
    REQUIRE(threw);
}

iprop::Canvas runProgCanvas(const Prog& prog, u32 sizeX, u32 sizeY) {
    // The meta stays 8x8; the requested size goes to the VM so scaling
    // applies (spec §8.1).
    const auto bytes = buildProgFile(prog); // must outlive the spans
    auto loaded = iprop::loadFile(bytes);
    iprop::VM vm(loaded, {0, 0, 0, sizeX, sizeY, {}});
    vm.run();
    return vm.canvas();
}

u32 bitsOf(f32 value) {
    u32 result = 0;
    std::memcpy(&result, &value, sizeof(result));
    return result;
}

f32 f32FromBits(u32 value) {
    f32 result = 0.f;
    std::memcpy(&result, &value, sizeof(result));
    return result;
}

void expectError(const std::vector<u8>& bytes, std::size_t at) {
    bool threw = false;
    try {
        (void)iprop::parseLayout(bytes);
    } catch (const iprop::FormatError& error) {
        threw = true;
        CHECK(error.offset == at);
    }
    REQUIRE(threw);
}

void expectMetaError(const std::vector<u8>& metaBytes, const std::vector<u8>& poolBytes,
                     std::size_t relOffset, const char* messagePart) {
    const auto bytes = fullFile(metaBytes, poolBytes);
    const auto layout = iprop::parseLayout(bytes);
    const auto pool = iprop::parseConsts(bytes, *layout.find(SectionId::Const));
    const std::size_t base = layout.find(SectionId::Meta)->offset;
    bool threw = false;
    try {
        (void)iprop::parseMeta(bytes, *layout.find(SectionId::Meta), pool);
    } catch (const iprop::FormatError& error) {
        threw = true;
        CHECK(error.offset == base + relOffset);
        CHECK(std::string(error.what()).find(messagePart) != std::string::npos);
    }
    REQUIRE(threw);
}

void expectConstError(const std::vector<u8>& poolBytes, std::size_t relOffset,
                      const char* messagePart) {
    const auto bytes = fullFile({}, poolBytes);
    const auto layout = iprop::parseLayout(bytes);
    const std::size_t base = layout.find(SectionId::Const)->offset;
    bool threw = false;
    try {
        (void)iprop::parseConsts(bytes, *layout.find(SectionId::Const));
    } catch (const iprop::FormatError& error) {
        threw = true;
        CHECK(error.offset == base + relOffset);
        CHECK(std::string(error.what()).find(messagePart) != std::string::npos);
    }
    REQUIRE(threw);
}

} // namespace test_support
