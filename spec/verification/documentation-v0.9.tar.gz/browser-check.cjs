const { chromium } = require('./browser/node_modules/playwright');
const fs=require('fs'),http=require('http'),path=require('path'),assert=require('assert/strict');
(async()=>{
 const base=path.join(__dirname,'site');
 const server=http.createServer((req,res)=>{
  const name=path.join(base,decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.wasm':'application/wasm','.svg':'image/svg+xml'};
  res.setHeader('Content-Type',types[path.extname(name)]||'application/octet-stream');
  try{res.end(fs.readFileSync(name.endsWith('/')?name+'index.html':name));}catch{res.statusCode=404;res.end('not found');}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 const url='http://127.0.0.1:'+server.address().port;
 await page.goto(url+'/docs/language.html');
 const migration=page.getByRole('heading',{name:'Migrating from 0.8 to 0.9',exact:true});await migration.scrollIntoViewIfNeeded();
 assert.equal(await migration.count(),1);
 assert.ok(await page.getByText('noise.mask',{exact:false}).count()>0);
 await page.screenshot({path:path.join(__dirname,'handbook-desktop.png'),animations:"disabled"});
 await page.setViewportSize({width:390,height:844});await migration.scrollIntoViewIfNeeded();
 await page.waitForFunction(()=>getComputedStyle(document.querySelector('.site-nav')).visibility==='hidden');
 await page.screenshot({path:path.join(__dirname,'handbook-mobile.png'),animations:'disabled'});
 await page.locator('[data-nav-toggle]').click();assert.equal(await page.locator('[data-nav-toggle]').getAttribute('aria-expanded'),'true');
 await page.keyboard.press('Escape');assert.equal(await page.locator('[data-nav-toggle]').getAttribute('aria-expanded'),'false');
 await page.setViewportSize({width:1100,height:850});await page.goto(url+'/editor-preview.html');
 await page.waitForFunction(()=>document.querySelector('#preview').naturalWidth===128);
 assert.match(await page.locator('#status').textContent(),/fuel: 137512/);
 assert.match(await page.locator('#outputs').textContent(),/Part snapshots/);
 await page.screenshot({path:path.join(__dirname,'editor-preview.png')});
 await page.locator('#seed-slider').fill('42');await page.locator('#seed-slider').dispatchEvent('input');
 assert.ok(await page.evaluate(()=>testMessages.some(m=>m.type==='slider'&&m.value===42)));
 assert.deepEqual(errors,[]);
 fs.writeFileSync(path.join(__dirname,'browser.json'),JSON.stringify({browser:await browser.version(),handbook:['1440x1000','390x844'],editor:'actual previewHtml with native rendered typed example; VS Code message bridge simulated',page_errors:errors,seed_control:true},null,2)+'\n');
 await browser.close();await new Promise(resolve=>server.close(resolve));console.log('PASS: real Chromium handbook desktop/mobile and editor webview render/seed bridge');
})().catch(e=>{console.error(e);process.exit(1)});
